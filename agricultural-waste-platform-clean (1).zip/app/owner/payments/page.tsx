"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import {
  Search,
  Filter,
  CreditCard,
  Coins,
  TrendingUp,
  Calendar,
  Download,
  ArrowUpRight,
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts"

const paymentsData = [
  {
    id: 1,
    farmer: "Kamal Perera",
    coins: 240,
    date: "Dec 15, 2024",
    wasteType: "Rice Straw",
    status: "completed",
  },
  {
    id: 2,
    farmer: "Nimal Silva",
    coins: 170,
    date: "Dec 14, 2024",
    wasteType: "Coconut Husks",
    status: "completed",
  },
  {
    id: 3,
    farmer: "Anura Jayawardena",
    coins: 400,
    date: "Dec 13, 2024",
    wasteType: "Sugarcane Bagasse",
    status: "completed",
  },
  {
    id: 4,
    farmer: "Ruwan Wickramasinghe",
    coins: 320,
    date: "Dec 12, 2024",
    wasteType: "Banana Stems",
    status: "pending",
  },
  {
    id: 5,
    farmer: "Mahinda Rathnayake",
    coins: 300,
    date: "Dec 11, 2024",
    wasteType: "Rice Straw",
    status: "completed",
  },
  {
    id: 6,
    farmer: "Sunil Fernando",
    coins: 180,
    date: "Dec 10, 2024",
    wasteType: "Paddy Husk",
    status: "completed",
  },
]

const monthlyData = [
  { month: "Jul", coins: 8500 },
  { month: "Aug", coins: 12300 },
  { month: "Sep", coins: 15800 },
  { month: "Oct", coins: 18200 },
  { month: "Nov", coins: 22500 },
  { month: "Dec", coins: 25420 },
]

const summaryStats = [
  {
    label: "Total Distributed",
    value: "125,420",
    change: "+15%",
    icon: Coins,
  },
  {
    label: "This Month",
    value: "25,420",
    change: "+8%",
    icon: Calendar,
  },
  {
    label: "Avg. per Farmer",
    value: "238",
    change: "+3%",
    icon: TrendingUp,
  },
  {
    label: "Transactions",
    value: "5,247",
    change: "+12%",
    icon: CreditCard,
  },
]

export default function PaymentsPage() {
  const [searchQuery, setSearchQuery] = useState("")

  const filteredPayments = paymentsData.filter((payment) =>
    payment.farmer.toLowerCase().includes(searchQuery.toLowerCase())
  )

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return (
          <Badge className="bg-primary/10 text-primary hover:bg-primary/20">
            Completed
          </Badge>
        )
      case "pending":
        return (
          <Badge className="bg-accent/20 text-accent-foreground hover:bg-accent/30">
            Pending
          </Badge>
        )
      default:
        return null
    }
  }

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Payments Management</h1>
          <p className="text-muted-foreground mt-1">
            Track eco-coins distribution and payment history
          </p>
        </div>
        <div className="flex items-center gap-3">
          <motion.div whileTap={{ scale: 0.97 }}>
            <Button variant="outline">
              <Download className="w-4 h-4 mr-2" />
              Export
            </Button>
          </motion.div>
        </div>
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {summaryStats.map((stat, index) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card>
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center">
                    <stat.icon className="w-5 h-5 text-primary" />
                  </div>
                  <span className="text-sm font-medium text-primary flex items-center gap-1">
                    <TrendingUp className="w-3 h-3" />
                    {stat.change}
                  </span>
                </div>
                <div className="mt-3">
                  <p className="text-2xl font-bold text-foreground">{stat.value}</p>
                  <p className="text-sm text-muted-foreground">{stat.label}</p>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Chart and Recent Payments */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* Monthly Distribution Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <Card className="h-full">
            <CardHeader>
              <CardTitle className="text-lg">Monthly Distribution</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[280px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={monthlyData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#D4E5D6" />
                    <XAxis dataKey="month" stroke="#4A5568" fontSize={12} />
                    <YAxis stroke="#4A5568" fontSize={12} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "#FFFFFF",
                        border: "1px solid #D4E5D6",
                        borderRadius: "12px",
                        boxShadow: "0 4px 6px -1px rgba(0, 0, 0, 0.1)",
                      }}
                      labelStyle={{ color: "#1B1B1B" }}
                      formatter={(value) => [`${value} coins`, "Distributed"]}
                    />
                    <Bar dataKey="coins" fill="#2E7D32" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Recent Payments */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <Card className="h-full">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-lg">Recent Distributions</CardTitle>
              <a
                href="#"
                className="text-sm text-primary hover:underline flex items-center gap-1"
              >
                View All <ArrowUpRight className="w-4 h-4" />
              </a>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {paymentsData.slice(0, 5).map((payment, index) => (
                  <motion.div
                    key={payment.id}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.6 + index * 0.1 }}
                    className="flex items-center justify-between p-3 rounded-xl bg-muted/50 hover:bg-muted transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <Avatar className="w-9 h-9">
                        <AvatarFallback className="bg-primary/10 text-primary text-sm">
                          {payment.farmer.charAt(0)}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium text-foreground text-sm">
                          {payment.farmer}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {payment.wasteType}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold text-primary flex items-center gap-1">
                        <Coins className="w-4 h-4" />
                        {payment.coins}
                      </p>
                      <p className="text-xs text-muted-foreground">{payment.date}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Full Payment History */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Payment History</CardTitle>
          <div className="flex items-center gap-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 w-48"
              />
            </div>
            <Button variant="outline" size="icon">
              <Filter className="w-4 h-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left py-3 px-4 font-medium text-muted-foreground text-sm">
                    Farmer
                  </th>
                  <th className="text-left py-3 px-4 font-medium text-muted-foreground text-sm">
                    Waste Type
                  </th>
                  <th className="text-left py-3 px-4 font-medium text-muted-foreground text-sm">
                    Coins
                  </th>
                  <th className="text-left py-3 px-4 font-medium text-muted-foreground text-sm hidden sm:table-cell">
                    Date
                  </th>
                  <th className="text-left py-3 px-4 font-medium text-muted-foreground text-sm">
                    Status
                  </th>
                </tr>
              </thead>
              <tbody>
                {filteredPayments.map((payment, index) => (
                  <motion.tr
                    key={payment.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                    className="border-b border-border last:border-0 hover:bg-muted/50 transition-colors"
                  >
                    <td className="py-4 px-4">
                      <div className="flex items-center gap-3">
                        <Avatar className="w-8 h-8">
                          <AvatarFallback className="bg-primary/10 text-primary text-xs">
                            {payment.farmer.charAt(0)}
                          </AvatarFallback>
                        </Avatar>
                        <span className="font-medium text-foreground">
                          {payment.farmer}
                        </span>
                      </div>
                    </td>
                    <td className="py-4 px-4 text-muted-foreground">
                      {payment.wasteType}
                    </td>
                    <td className="py-4 px-4">
                      <span className="font-semibold text-primary flex items-center gap-1">
                        <Coins className="w-4 h-4" />
                        {payment.coins}
                      </span>
                    </td>
                    <td className="py-4 px-4 text-muted-foreground hidden sm:table-cell">
                      {payment.date}
                    </td>
                    <td className="py-4 px-4">{getStatusBadge(payment.status)}</td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
