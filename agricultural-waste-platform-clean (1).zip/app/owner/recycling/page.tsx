"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import {
  Search,
  Filter,
  Plus,
  ArrowRight,
  Package,
  Recycle,
  Factory,
  Leaf,
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"

const recyclingData = [
  {
    id: 1,
    wasteType: "Rice Straw",
    inputQuantity: "500 kg",
    outputProduct: "Biodegradable Packaging",
    outputQuantity: "200 units",
    processDate: "Dec 10, 2024",
    status: "completed",
    facility: "EcoProcess Colombo",
  },
  {
    id: 2,
    wasteType: "Coconut Husks",
    inputQuantity: "300 kg",
    outputProduct: "Coir Products",
    outputQuantity: "150 kg",
    processDate: "Dec 08, 2024",
    status: "completed",
    facility: "CoirTech Galle",
  },
  {
    id: 3,
    wasteType: "Sugarcane Bagasse",
    inputQuantity: "800 kg",
    outputProduct: "Biofuel Pellets",
    outputQuantity: "600 kg",
    processDate: "Dec 05, 2024",
    status: "processing",
    facility: "BioEnergy Kandy",
  },
  {
    id: 4,
    wasteType: "Banana Stems",
    inputQuantity: "250 kg",
    outputProduct: "Organic Fertilizer",
    outputQuantity: "400 kg",
    processDate: "Dec 01, 2024",
    status: "completed",
    facility: "GreenCompost Matara",
  },
  {
    id: 5,
    wasteType: "Rice Straw",
    inputQuantity: "1000 kg",
    outputProduct: "Paper Products",
    outputQuantity: "350 reams",
    processDate: "Nov 28, 2024",
    status: "completed",
    facility: "EcoPaper Mills",
  },
]

const summaryStats = [
  { label: "Total Input", value: "2,850 kg", icon: Package, color: "primary" },
  { label: "Products Created", value: "1,700+", icon: Recycle, color: "secondary" },
  { label: "Facilities", value: "5", icon: Factory, color: "accent" },
  { label: "CO2 Saved", value: "1.2T", icon: Leaf, color: "primary" },
]

export default function RecyclingPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)

  const filteredData = recyclingData.filter(
    (item) =>
      item.wasteType.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.outputProduct.toLowerCase().includes(searchQuery.toLowerCase())
  )

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return (
          <Badge className="bg-primary/10 text-primary hover:bg-primary/20">
            Completed
          </Badge>
        )
      case "processing":
        return (
          <Badge className="bg-accent/20 text-accent-foreground hover:bg-accent/30">
            Processing
          </Badge>
        )
      default:
        return null
    }
  }

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Recycling Tracking</h1>
          <p className="text-muted-foreground mt-1">
            Track waste to product transformation
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 w-48 sm:w-64"
            />
          </div>
          <Button variant="outline" size="icon">
            <Filter className="w-4 h-4" />
          </Button>
          <motion.div whileTap={{ scale: 0.97 }}>
            <Button
              onClick={() => setIsAddDialogOpen(true)}
              className="bg-primary text-primary-foreground hover:bg-primary/90"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Record
            </Button>
          </motion.div>
        </div>
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {summaryStats.map((stat, index) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card>
              <CardContent className="p-4 flex items-center gap-4">
                <div
                  className={`w-12 h-12 rounded-2xl flex items-center justify-center ${
                    stat.color === "primary"
                      ? "bg-primary/10"
                      : stat.color === "secondary"
                        ? "bg-secondary"
                        : "bg-accent/20"
                  }`}
                >
                  <stat.icon
                    className={`w-6 h-6 ${
                      stat.color === "primary"
                        ? "text-primary"
                        : stat.color === "secondary"
                          ? "text-primary"
                          : "text-accent-foreground"
                    }`}
                  />
                </div>
                <div>
                  <p className="text-2xl font-bold text-foreground">{stat.value}</p>
                  <p className="text-sm text-muted-foreground">{stat.label}</p>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Recycling Records */}
      <Card>
        <CardHeader>
          <CardTitle>Waste to Product Mapping</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left py-3 px-4 font-medium text-muted-foreground text-sm">
                    Waste Type
                  </th>
                  <th className="text-left py-3 px-4 font-medium text-muted-foreground text-sm">
                    Input
                  </th>
                  <th className="text-left py-3 px-4 font-medium text-muted-foreground text-sm hidden sm:table-cell">
                    Output
                  </th>
                  <th className="text-left py-3 px-4 font-medium text-muted-foreground text-sm hidden md:table-cell">
                    Facility
                  </th>
                  <th className="text-left py-3 px-4 font-medium text-muted-foreground text-sm">
                    Status
                  </th>
                </tr>
              </thead>
              <tbody>
                {filteredData.map((item, index) => (
                  <motion.tr
                    key={item.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                    className="border-b border-border last:border-0 hover:bg-muted/50 transition-colors"
                  >
                    <td className="py-4 px-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center">
                          <Package className="w-5 h-5 text-primary" />
                        </div>
                        <div>
                          <p className="font-medium text-foreground">
                            {item.wasteType}
                          </p>
                          <p className="text-sm text-muted-foreground">
                            {item.processDate}
                          </p>
                        </div>
                      </div>
                    </td>
                    <td className="py-4 px-4 text-foreground">
                      {item.inputQuantity}
                    </td>
                    <td className="py-4 px-4 hidden sm:table-cell">
                      <div className="flex items-center gap-2">
                        <ArrowRight className="w-4 h-4 text-primary" />
                        <div>
                          <p className="font-medium text-foreground">
                            {item.outputProduct}
                          </p>
                          <p className="text-sm text-muted-foreground">
                            {item.outputQuantity}
                          </p>
                        </div>
                      </div>
                    </td>
                    <td className="py-4 px-4 text-muted-foreground hidden md:table-cell">
                      {item.facility}
                    </td>
                    <td className="py-4 px-4">{getStatusBadge(item.status)}</td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Add Record Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Recycling Record</DialogTitle>
            <DialogDescription>
              Record a new waste to product transformation
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Waste Type</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select waste type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="rice-straw">Rice Straw</SelectItem>
                  <SelectItem value="coconut-husks">Coconut Husks</SelectItem>
                  <SelectItem value="sugarcane-bagasse">Sugarcane Bagasse</SelectItem>
                  <SelectItem value="banana-stems">Banana Stems</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Input Quantity (kg)</Label>
                <Input type="number" placeholder="e.g., 500" />
              </div>
              <div className="space-y-2">
                <Label>Output Product</Label>
                <Input placeholder="e.g., Biofuel Pellets" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Output Quantity</Label>
                <Input placeholder="e.g., 300 kg" />
              </div>
              <div className="space-y-2">
                <Label>Processing Facility</Label>
                <Input placeholder="e.g., EcoProcess Colombo" />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
              Cancel
            </Button>
            <motion.div whileTap={{ scale: 0.97 }}>
              <Button
                className="bg-primary text-primary-foreground hover:bg-primary/90"
                onClick={() => setIsAddDialogOpen(false)}
              >
                Add Record
              </Button>
            </motion.div>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
