"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import Image from "next/image"
import {
  Search,
  Filter,
  CheckCircle,
  XCircle,
  MapPin,
  Calendar,
  Scale,
  Coins,
  Eye,
  ImageIcon,
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Label } from "@/components/ui/label"

const wasteSubmissions = [
  {
    id: 1,
    farmer: "Kamal Perera",
    wasteType: "Rice Straw",
    quantity: "120 kg",
    location: "Anuradhapura",
    date: "Dec 15, 2024",
    status: "pending",
    estimatedCoins: 240,
    image: "/images/farmer-collecting-waste.jpg",
    notes: "Collected from 2 acres of paddy field after harvest",
  },
  {
    id: 2,
    farmer: "Nimal Silva",
    wasteType: "Coconut Husks",
    quantity: "85 kg",
    location: "Polonnaruwa",
    date: "Dec 14, 2024",
    status: "pending",
    estimatedCoins: 170,
    image: "/images/farmer-collecting-waste.jpg",
    notes: "From coconut processing unit",
  },
  {
    id: 3,
    farmer: "Anura Jayawardena",
    wasteType: "Sugarcane Bagasse",
    quantity: "200 kg",
    location: "Matale",
    date: "Dec 13, 2024",
    status: "verified",
    estimatedCoins: 400,
    image: "/images/farmer-collecting-waste.jpg",
    notes: "Large batch from sugarcane processing",
  },
  {
    id: 4,
    farmer: "Ruwan Wickramasinghe",
    wasteType: "Banana Stems",
    quantity: "95 kg",
    location: "Galle",
    date: "Dec 12, 2024",
    status: "rejected",
    estimatedCoins: 190,
    image: "/images/farmer-collecting-waste.jpg",
    notes: "Image quality was poor, asked for resubmission",
  },
  {
    id: 5,
    farmer: "Mahinda Rathnayake",
    wasteType: "Rice Straw",
    quantity: "150 kg",
    location: "Hambantota",
    date: "Dec 11, 2024",
    status: "pending",
    estimatedCoins: 300,
    image: "/images/farmer-collecting-waste.jpg",
    notes: "First submission from this farmer",
  },
]

export default function VerifyWastePage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedSubmission, setSelectedSubmission] = useState<typeof wasteSubmissions[0] | null>(null)
  const [isDetailOpen, setIsDetailOpen] = useState(false)
  const [coinsToAssign, setCoinsToAssign] = useState("")

  const filteredSubmissions = wasteSubmissions.filter(
    (sub) =>
      sub.farmer.toLowerCase().includes(searchQuery.toLowerCase()) ||
      sub.wasteType.toLowerCase().includes(searchQuery.toLowerCase())
  )

  const pendingCount = wasteSubmissions.filter((s) => s.status === "pending").length

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return (
          <Badge className="bg-accent/20 text-accent-foreground hover:bg-accent/30">
            Pending
          </Badge>
        )
      case "verified":
        return (
          <Badge className="bg-primary/10 text-primary hover:bg-primary/20">
            Verified
          </Badge>
        )
      case "rejected":
        return (
          <Badge className="bg-destructive/10 text-destructive hover:bg-destructive/20">
            Rejected
          </Badge>
        )
      default:
        return null
    }
  }

  const handleViewDetails = (submission: typeof wasteSubmissions[0]) => {
    setSelectedSubmission(submission)
    setCoinsToAssign(submission.estimatedCoins.toString())
    setIsDetailOpen(true)
  }

  const handleApprove = () => {
    // Handle approval logic
    setIsDetailOpen(false)
  }

  const handleReject = () => {
    // Handle rejection logic
    setIsDetailOpen(false)
  }

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Waste Verification</h1>
          <p className="text-muted-foreground mt-1">
            Review and verify farmer waste submissions
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search submissions..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 w-64"
            />
          </div>
          <Button variant="outline" size="icon">
            <Filter className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Pending Alert */}
      {pendingCount > 0 && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <Card className="border-accent/50 bg-accent/5">
            <CardContent className="p-4 flex items-center gap-4">
              <div className="w-10 h-10 bg-accent/20 rounded-full flex items-center justify-center">
                <Scale className="w-5 h-5 text-accent-foreground" />
              </div>
              <div>
                <p className="font-medium text-foreground">
                  {pendingCount} submissions awaiting verification
                </p>
                <p className="text-sm text-muted-foreground">
                  Review and approve or reject the pending waste submissions
                </p>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      )}

      {/* Submissions List */}
      <div className="grid gap-4">
        <AnimatePresence>
          {filteredSubmissions.map((submission, index) => (
            <motion.div
              key={submission.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ delay: index * 0.05 }}
            >
              <Card className="hover:shadow-md transition-shadow duration-200">
                <CardContent className="p-4 sm:p-6">
                  <div className="flex flex-col sm:flex-row gap-4">
                    {/* Image Preview */}
                    <div className="relative w-full sm:w-32 h-32 bg-muted rounded-xl overflow-hidden flex-shrink-0">
                      <Image
                        src={submission.image || "/placeholder.svg"}
                        alt={submission.wasteType}
                        fill
                        className="object-cover"
                      />
                      <button
                        onClick={() => handleViewDetails(submission)}
                        className="absolute inset-0 bg-foreground/50 opacity-0 hover:opacity-100 transition-opacity flex items-center justify-center"
                      >
                        <Eye className="w-6 h-6 text-card" />
                      </button>
                    </div>

                    {/* Details */}
                    <div className="flex-1 min-w-0">
                      <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2">
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <h3 className="font-semibold text-foreground">
                              {submission.wasteType}
                            </h3>
                            {getStatusBadge(submission.status)}
                          </div>
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <Avatar className="w-5 h-5">
                              <AvatarFallback className="bg-primary/10 text-primary text-xs">
                                {submission.farmer.charAt(0)}
                              </AvatarFallback>
                            </Avatar>
                            {submission.farmer}
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="flex items-center gap-1 text-primary font-medium">
                            <Coins className="w-4 h-4" />
                            {submission.estimatedCoins}
                          </div>
                        </div>
                      </div>

                      <div className="flex flex-wrap gap-4 mt-3 text-sm text-muted-foreground">
                        <div className="flex items-center gap-1">
                          <Scale className="w-4 h-4" />
                          {submission.quantity}
                        </div>
                        <div className="flex items-center gap-1">
                          <MapPin className="w-4 h-4" />
                          {submission.location}
                        </div>
                        <div className="flex items-center gap-1">
                          <Calendar className="w-4 h-4" />
                          {submission.date}
                        </div>
                      </div>

                      {submission.status === "pending" && (
                        <div className="flex gap-2 mt-4">
                          <motion.div whileTap={{ scale: 0.97 }}>
                            <Button
                              size="sm"
                              onClick={() => handleViewDetails(submission)}
                              className="bg-primary text-primary-foreground hover:bg-primary/90"
                            >
                              <CheckCircle className="w-4 h-4 mr-1" />
                              Review
                            </Button>
                          </motion.div>
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Detail Dialog */}
      <Dialog open={isDetailOpen} onOpenChange={setIsDetailOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Verify Waste Submission</DialogTitle>
            <DialogDescription>
              Review the details and approve or reject this submission
            </DialogDescription>
          </DialogHeader>
          {selectedSubmission && (
            <div className="space-y-4">
              {/* Image */}
              <div className="relative w-full h-48 bg-muted rounded-xl overflow-hidden">
                <Image
                  src={selectedSubmission.image || "/placeholder.svg"}
                  alt={selectedSubmission.wasteType}
                  fill
                  className="object-cover"
                />
              </div>

              {/* Details Grid */}
              <div className="grid grid-cols-2 gap-4">
                <div className="p-3 bg-muted rounded-xl">
                  <p className="text-xs text-muted-foreground">Farmer</p>
                  <p className="font-medium text-foreground">{selectedSubmission.farmer}</p>
                </div>
                <div className="p-3 bg-muted rounded-xl">
                  <p className="text-xs text-muted-foreground">Waste Type</p>
                  <p className="font-medium text-foreground">{selectedSubmission.wasteType}</p>
                </div>
                <div className="p-3 bg-muted rounded-xl">
                  <p className="text-xs text-muted-foreground">Quantity</p>
                  <p className="font-medium text-foreground">{selectedSubmission.quantity}</p>
                </div>
                <div className="p-3 bg-muted rounded-xl">
                  <p className="text-xs text-muted-foreground">Location</p>
                  <p className="font-medium text-foreground">{selectedSubmission.location}</p>
                </div>
              </div>

              {/* Notes */}
              <div className="p-3 bg-muted rounded-xl">
                <p className="text-xs text-muted-foreground">Farmer Notes</p>
                <p className="text-sm text-foreground">{selectedSubmission.notes}</p>
              </div>

              {/* Coins Assignment */}
              {selectedSubmission.status === "pending" && (
                <div className="space-y-2">
                  <Label htmlFor="coins">Eco-Coins to Assign</Label>
                  <Input
                    id="coins"
                    type="number"
                    value={coinsToAssign}
                    onChange={(e) => setCoinsToAssign(e.target.value)}
                    className="w-full"
                  />
                  <p className="text-xs text-muted-foreground">
                    Estimated: {selectedSubmission.estimatedCoins} coins (2 coins per kg)
                  </p>
                </div>
              )}
            </div>
          )}
          {selectedSubmission?.status === "pending" && (
            <DialogFooter className="flex gap-2 sm:gap-0">
              <motion.div whileTap={{ scale: 0.97 }}>
                <Button
                  variant="outline"
                  onClick={handleReject}
                  className="border-destructive text-destructive hover:bg-destructive/10 bg-transparent"
                >
                  <XCircle className="w-4 h-4 mr-1" />
                  Reject
                </Button>
              </motion.div>
              <motion.div whileTap={{ scale: 0.97 }}>
                <Button
                  onClick={handleApprove}
                  className="bg-primary text-primary-foreground hover:bg-primary/90"
                >
                  <CheckCircle className="w-4 h-4 mr-1" />
                  Approve & Assign Coins
                </Button>
              </motion.div>
            </DialogFooter>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
